# Smart-Textile-with-modules
 This repo contains all the modules. Just open Command Prompt and 'npm run serve'
