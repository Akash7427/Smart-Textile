const express = require('express');
const myrouter = express.Router();
const bodyParser = require('body-parser');
const dbName = 'Producer';
const admin = require('firebase-admin');
const db = admin.firestore();

myrouter.get('/',(req,res) => {
    res.send('Hello-world!');
});


myrouter.post('/create',(req,res) => {
    ( async() => {
       
            let query1 = db.collection(dbName);  
            let checkGSTArr = [];
            let checkFlag = 1;

            await query1.get().then(querySnapshot1 => {
                let docs1 = querySnapshot1.docs;

                for(let i of docs1)
                {
                    const selectedItem1 =
                        i.data().GST_num;
                   
                    checkGSTArr.push(selectedItem1);
                }
                return true;
            })
            if(checkGSTArr !== null){
                for(i = 0; i < checkGSTArr.length; i++){
                    if(req.body.GST_num === checkGSTArr[i]){
                        console.log('GST number already present in the database.')
                        checkFlag = 0;
                        break;
                    }
                }
            }
            
        try
        {
            if (checkFlag === 0){
                console.log('Error writing into database: Same GST number found!');
           return res.status(600).send("Error: Same GST number found!");
       }
       else{
           
           await db.collection(dbName).doc('/' + req.body.id + '/')
                .create({
                        
                    name: req.body.name,
                    company_name: req.body.company_name,
                    Address: req.body.Address,
                    City: req.body.City,
                    State: req.body.State,
                    Pincode: req.body.Pincode,
                    phone_no: req.body.phone_no,
                    email: req.body.email,
                    logo: req.body.logo,
                    GST_num: req.body.GST_num,
                    Establishment_year: req.body.Establishment_year,
                    category: req.body.category,
                    Rating: req.body.Rating,
                    Device_token: req.body.Device_token
            })
            console.log('Data---Added');
            return res.status(200).send();
        
       }
    }

        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
   // next();
    });


//Check GST ~ Get
myrouter.get('/check/:num', (req,res) => {
    let query = db.collection(dbName).where('GST_num', '==', req.params.num).get()
    .then(snap => {
        if(snap.empty){
            console.log('No such GST number was found.');
            return res.status(200).send("No such GST number was found.");
        }
        else{
            console.log('Same GST number found.');
            return res.status(500).send('Same GST number found.');
        }
    })
})



//read specific user by id
//get
myrouter.get('/read/:id', (req,res) => {
    ( async() => {
        try
        {
            const document = db.collection(dbName).doc(req.params.id); 
            let producer = await document.get();  
            let response = producer.data();  

            console.log('----Read Data----');
            return res.status(200).send(response);
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
    //next();
    });

//Filter ~ Get
myrouter.get('/filter/:key/:value',(req,res) => {
    (async() => {
        try
        {
            let query = db.collection(dbName).orderBy("Rating","desc");  
            let response = [] ;

            await query.where(req.params.key, '==', req.params.value).get().then(querySnapshot => {
                let docs = querySnapshot.docs;

                for(let doc of docs)
                {
                    const selectedItem = {
                        id: doc.id,
                        name: doc.data().name,
                        company_name: doc.data().company_name,
                        Address: doc.data().Address,
                        City: doc.data().City,
                        State: doc.data().State,
                        Pincode: doc.data().Pincode,
                        phone_no: doc.data().phone_no,
                        email: doc.data().email,
                        logo: doc.data().logo,
                        GST_num: doc.data().GST_num,
                        Establishment_year: doc.data().Establishment_year,
                        category: doc.data().category,
                        Rating: doc.data().Rating
                    };
                    response.push(selectedItem);
                }
                return response; 
            })

            console.log('----Read Required Data----');
            return res.status(200).send(response);
       }
        catch(error) 
        {
            console.log('Error!');
            return res.status(500).send(Error);
        }
    })();
});



//read all
//get
myrouter.get('/read', (req,res) => {
    ( async() => {
        try
        {
            let query = db.collection(dbName).orderBy("Rating","desc");  
            let response = [] ;

            await query.get().then(querySnapshot => {
                let docs = querySnapshot.docs;

                for(let doc of docs)
                {
                    const selectedItem = {
                       
                        id: doc.id,
                        name: doc.data().name,
                        company_name: doc.data().company_name,
                        Address: doc.data().Address,
                        City: doc.data().City,
                        State: doc.data().State,
                        Pincode: doc.data().Pincode,
                        phone_no: doc.data().phone_no,
                        email: doc.data().email,
                        logo: doc.data().logo,
                        GST_num: doc.data().GST_num,
                        Establishment_year: doc.data().Establishment_year,
                        category: doc.data().category,
                        Rating: doc.data().Rating
                    };
                    response.push(selectedItem);
                }
                return response; 
            })

            console.log('----Read All Data----');
            return res.status(200).send(response);
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
    
    });

//update
myrouter.put('/update/:id', (req,res) => {
    ( async() => {
        try
        {
               const document = db.collection(dbName).doc(req.params.id);

               await document.update({
                name: req.body.name,
                    company_name: req.body.company_name,
                    Address: req.body.Address,
                    City: req.body.City,
                    State: req.body.State,
                    Pincode: req.body.Pincode,
                    phone_no: req.body.phone_no,
                    email: req.body.email,
                    logo: req.body.logo,
                    GST_num: req.body.GST_num,
                    Establishment_year: req.body.Establishment_year,
                    category: req.body.category
               });

            console.log('---- Data Updated ----');
            return res.status(200).send();
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
    
    });

//delete
myrouter.delete('/delete/:id',(req,res) => {
    (async() => {

        try
        {
            const document = db.collection(dbName).doc(req.params.id);
            await document.delete();
            return res.status(500).send(error);
        }
        catch(error)
        {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});



module.exports = myrouter;

