const express = require('express');
const myrouter = express.Router();
const bodyParser = require('body-parser');

const admin = require('firebase-admin');
const db = admin.firestore();

myrouter.get('/',(req,res) => {
    res.send('Hello-world!');
});

//Create
//Post
myrouter.post('/create',(req,res) => {
    ( async() => {
       
            let query1 = db.collection('Transporter');  
            let checkGSTArr = [];
            let checkFlag = 1;

            await query1.get().then(querySnapshot1 => {
                let docs1 = querySnapshot1.docs;

                for(let i of docs1)
                {
                    const selectedItem1 = 
                i.data().GST_num;
                    
                    checkGSTArr.push(selectedItem1);
                }
                return true;
            })
            if(checkGSTArr !== null){
                for(i = 0; i < checkGSTArr.length; i++){
                    if(req.body.GST_num === checkGSTArr[i]){
                        console.log('GST number already present in the database.')
                        checkFlag = 0;
                        break;
                    }
                }
            }
            
        try
        {
            if (checkFlag === 0){
                console.log('Error writing into database: Same GST number found!');
           return res.status(600).send("Error: Same GST number found!");
       }
       else{
          
           await db.collection('Transporter').doc('/' + req.body.id + '/')
                .create({
                    name: req.body.name,
                    company_name: req.body.company_name,
                    Address: req.body.Address,
                    City: req.body.City,
                    State: req.body.State,
                    Pincode: req.body.Pincode,
                    phone_no: req.body.phone_no,
                    email: req.body.email,
                    //logo: req.body.logo,
                    GST_num: req.body.GST_num,
                    Establishment_year: req.body.Establishment_year
                        // Device_token: req.body.Device_token
            })
            console.log('Data---Added');
            return res.status(200).send();
       }
    }

        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
   // next();
    });

//read specific user by id
//get
myrouter.get('/read/:id', (req,res) => {
    ( async() => {
        try
        {
            const document = db.collection('Transporter').doc(req.params.id); 
            let producer = await document.get();  
            let response = producer.data();  
            console.log('----Read Data----');
            return res.status(200).send(response);
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
    //next();
    });

//read all
//get
myrouter.get('/read', (req,res) => {
    ( async() => {
        try
        {
            let query = db.collection('Transporter');  
            let response = [] ;

            await query.get().then(querySnapshot => {
                let docs = querySnapshot.docs;

                for(let doc of docs)
                {
                    const selectedItem = {
                       
                        id: doc.id,
                        name: doc.data().name,
                        company_name: doc.data().company_name,
                        Address: doc.data().Address,
                        City: doc.data().City,
                        State: doc.data().State,
                        Pincode: doc.data().Pincode,
                        phone_no: doc.data().phone_no,
                        email: doc.data().email,
                        //logo: doc.data().logo,
                        GST_num: doc.data().GST_num,
                        Establishment_year: doc.data().Establishment_year
                    };
                    response.push(selectedItem);
                }
                return response; 
            })

            console.log('----Read All Data----');
            return res.status(200).send(response);
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
    
    });

//update
myrouter.put('/update/:id', (req,res) => {
    ( async() => {
        try
        {
               const document = db.collection('Transporter').doc(req.params.id);

               await document.update({
                name: req.body.name,
                company_name: req.body.company_name,
                Address: req.body.Address,
                City: req.body.City,
                State: req.body.State,
                Pincode: req.body.Pincode,
                phone_no: req.body.phone_no,
                email: req.body.email,
                //logo: req.body.logo,
                GST_num: req.body.GST_num,
                Establishment_year: req.body.Establishment_year
               });

            console.log('---- Data Updated ----');
            return res.status(200).send();
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).send(error);
        }
    })();
    
    });

//delete
myrouter.delete('/delete/:id',(req,res) => {
    (async() => {

        try
        {
            const document = db.collection('Transporter').doc(req.params.id);
            await document.delete();
            return res.status(500).send(error);
        }
        catch(error)
        {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});
module.exports = myrouter;

