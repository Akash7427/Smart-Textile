const express = require('express');
const myrouter = express.Router();
const bodyParser = require('body-parser');
const admin = require('firebase-admin');
const db = admin.firestore();
const dbName = 'users';

myrouter.get('/',(req,res) => {
    res.send('Hello-world!');
});


//Create
//Post
myrouter.post('/create/:id',(req,res) => {
    ( async() => {
        
        var checkFlag = 1;
        let query = db.collection(dbName).where('GST_num', '==', req.body.gst_num).get()
        .then(snap => {
            if(snap.empty){
                checkFlag = 1;
                console.log('No such GST number was found.');
                return res.status(200).json();
            }
            else{
                var checkFlag = 0;
                console.log('Same GST number found.');
                return res.status(500).json('Same GST number found.');
            }
        })
    
            
        try
        {
            if (checkFlag === 0){
                console.log('Error writing into database: Same GST number found!');
           return res.status(600).json("Error: Same GST number found!");
       }
       else{
           
           await db.collection(dbName).doc('/' + req.params.id + '/')
                .create({
                    uid: req.body.uid, 
                    name: req.body.name,
                    company_name: req.body.company_name,
                    address: req.body.address,
                    city: req.body.city,
                    state: req.body.state,
                    pincode: req.body.pincode,
                    phone_no: req.body.phone_no,
                    email: req.body.email,
                    logo: req.body.logo,
                    website: req.body.website,
                    gst_num: req.body.gst_num,
                    establishment_year: req.body.establishment_year,
                    categories: req.body.categories,
                    device_token: req.body.device_token,
                    rating: req.body.rating,
                    type: req.body.type,
                    Saree: req.body.Saree,
                    Dress: req.body.Dress,
                    Ethnic_Wear: req.body.Ethnic_Wear,
                    Kurti: req.body.Kurti,
                    Apparel_And_Garments: req.body.Apparel_And_Garments,
                    Fabrics: req.body.Fabrics,
                    favourites: req.body.favourites,
                    products: req.body.products,
                    description: req.body.description

                })
            console.log('--- Data Added ---');
            return res.status(200).json("Data Added!");
        
       }
    }

        catch(error) 
        {
            console.log('--- Error ---');
            return res.status(500).json({error});
        }
    })();
   // next();
    });



//Check GST ~ Get
myrouter.get('/check/:num', (req,res) => {
    let query = db.collection(dbName).where('gst_num', '==', req.params.num).get()
    .then(snap => {
        if(snap.empty){
            console.log('No such GST number was found.');
            return res.status(200).send("No such GST number was found.");
        }
        else{
            console.log('Same GST number found.');
            return res.status(500).send('Same GST number found.');
        }
    })
})

//read specific user by id
//get
myrouter.get('/read/:id', (req,res) => {
    ( async() => {
        try
        {
            const document = db.collection(dbName).doc(req.params.id); 
            let producer = await document.get();  
            let response = producer.data();  
            console.log('----Read Data----');
            return res.status(200).json(response);
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).json(error);
        }
    })();
    //next();
    });


//Filter ~ Get
myrouter.get('/filter/:value/:categ', (req,res) => {
    ( async() => {
        try
        {
            let query = db.collection(dbName).orderBy('rating', "desc");  
            let response = [] ;

            await query.where("type", "==", req.params.value)
            .where('categories', 'array-contains-any', [req.params.categ])
            .get().then(snap => {
                if(snap.empty){
                    console.log("No data");
                    return res.status(500).json("No such data.");
                }else{
                
                let docs = snap.docs;

                for(let doc of docs)
                {
                    const selectedItem = {
                        id: doc.id,
                        uid: doc.data().uid,
                        name: doc.data().name,
                        company_name: doc.data().company_name,
                        address: doc.data().address,
                        city: doc.data().city,
                        state: doc.data().state,
                        pincode: doc.data().pincode,
                        phone_no: doc.data().phone_no,
                        email: doc.data().email,
                        logo: doc.data().logo,
                        website: doc.data().website,
                        gst_num: doc.data().gst_num,
                        establishment_year: doc.data().establishment_year,
                        categories: doc.data().categories,
                        rating: doc.data().rating,
                        type: doc.data().type,
                        Saree: doc.data().Saree,
                        Dress: doc.data().Dress,
                        Ethnic_Wear: doc.data().Ethnic_Wear,
                        Kurti: doc.data().Kurti,
                        Apparel_And_Garments: doc.data().Apparel_And_Garments,
                        Fabrics: doc.data().Fabrics,
                        favourites: doc.data().favourites,
                        products: doc.data().products,
                        description: doc.data().description
                    
                    };
                    response.push(selectedItem);
                }
                return response; 
            }
            })

            console.log('----Read All Data----');
            return res.status(200).json(response);
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).json(error);
        }
    })();
    
    });



//read all
//get



myrouter.get('/read', (req,res) => {
    ( async() => {
        try
        {
            let query = db.collection(dbName).orderBy('rating', "desc");  
            let response = [] ;

            await query.get().then(querySnapshot => {
                let docs = querySnapshot.docs;

                for(let doc of docs)
                {
                    const selectedItem = {
                        id: doc.id,
                        uid: doc.data().uid,
                        name: doc.data().name,
                        company_name: doc.data().company_name,
                        address: doc.data().address,
                        city: doc.data().city,
                        state: doc.data().state,
                        pincode: doc.data().pincode,
                        phone_no: doc.data().phone_no,
                        email: doc.data().email,
                        logo: doc.data().logo,
                        website: doc.data().website,
                        gst_num: doc.data().gst_num,
                        establishment_year: doc.data().establishment_year,
                        categories: doc.data().categories,
                        rating: doc.data().rating,
                        type: doc.data().type,
                        Saree: doc.data().Saree,
                        Dress: doc.data().Dress,
                        Ethnic_Wear: doc.data().Ethnic_Wear,
                        Kurti: doc.data().Kurti,
                        Apparel_And_Garments: doc.data().Apparel_And_Garments,
                        Fabrics: doc.data().Fabrics,
                        favourites: doc.data().favourites,
                        products: doc.data().products,
                        description: doc.data().description
                    
                    };
                    response.push(selectedItem);
                }
                return response; 
            })

            console.log('----Read All Data----');
            return res.status(200).json(response);
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).json(error);
        }
    })();
    
    });

//update
myrouter.put('/update/:id', (req,res) => {
    ( async() => {
        try
        {
               const document = db.collection(dbName).doc(req.params.id);

               await document.update({
                    uid:req.body.uid,
                    name: req.body.name,
                    company_name: req.body.company_name,
                    address: req.body.address,
                    city: req.body.city,
                    state: req.body.state,
                    pincode: req.body.pincode,
                    phone_no: req.body.phone_no,
                    email: req.body.email,
                    logo: req.body.logo,
                    website: req.body.website,
                    gst_num: req.body.gst_num,
                    establishment_year: req.body.establishment_year,
                    categories: req.body.categories,
                    rating: req.body.rating,
                    type: req.body.type,
                    Saree: req.body.Saree,
                    Dress: req.body.Dress,
                    Ethnic_Wear: req.body.Ethnic_Wear,
                    Kurti: req.body.Kurti,
                    Apparel_And_Garments: req.body.Apparel_And_Garments,
                    Fabrics: req.body.Fabrics,
                    favourites: req.body.favourites,
                    products: req.body.products,
                    description: req.body.description
                    
               });

            console.log('---- Data Updated ----');
            return res.status(200).json();
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).json(error);
        }
    })();
    
    });


//Update-Device Token 

myrouter.put('/update-d/:id/:device_token', (req,res) => {
    ( async() => {
        try
        {
               const document = db.collection(dbName).doc(req.params.id);

               const a = document.update({
                    device_token: req.params.device_token
               });

            console.log('---- Device Token Updated ----');
            return res.status(200).json();
       }
        catch(error) 
        {
            console.log('Error');
            return res.status(500).json(error);
        }
    })();
    
    });

//delete
myrouter.delete('/delete/:id',(req,res) => {
    (async() => {

        try
        {
            const document = db.collection(dbName).doc(req.params.id);
            await document.delete();
            return res.status(200).json();
        }
        catch(error)
        {
            console.log(error);
            return res.status(500).json(error);
        }
    })();
});
module.exports = myrouter;